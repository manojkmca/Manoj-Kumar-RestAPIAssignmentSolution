package com.greatlearning.ems.dto;

import lombok.Data;

@Data
public class EmployeeDto {

	private String firstName;

	private String lastName;

	private String email;

}
